#include <iostream>

#include "llvm/IR/DebugInfo.h"
#include "llvm/Pass.h"
#include "llvm/ADT/Statistic.h"
#include "llvm/Passes/PassPlugin.h"
#include "llvm/Passes/PassBuilder.h"

#include "llvm/IR/Module.h"
#include "llvm/IR/Function.h"
#include "llvm/IR/BasicBlock.h"
#include "llvm/IR/IntrinsicInst.h"
#include "llvm/IR/Instructions.h"
#include "llvm/IR/Constants.h"
#include "llvm/IR/IRBuilder.h"
#include "llvm/IR/PassManager.h"

#include "llvm/Support/raw_ostream.h"

using namespace llvm;
using namespace std;


namespace {
  class IntWrite: public PassInfoMixin<IntWrite> {
	public:
		Type *intTy, *ptrTy, *voidTy, *boolTy ; // These variables are to store the type instances for primitive types.
		
		FunctionCallee p_init ; // points to the function instance of _init_.
		FunctionCallee p_probe ; // points to the function instance of _probe_.

		IRBuilder<> * IRB;

		PreservedAnalyses run(Module &M, ModuleAnalysisManager &MAM) {
			if (!doInitialization(M)) {
				errs() << "Error: initialization of intwrite pass failed.\n" ;
				exit(1) ;
			}

			/* Invoke runOnBasicBlock() for each basic block under F. */

			for (llvm::Function &F : M) {
				for (llvm::BasicBlock &BB : F) {
					runOnBasicBlock(BB) ;
				}
			}
			return PreservedAnalyses::none();
		}

		bool doInitialization(Module &M) {
			/* This function is for initialization and the module level 
			 * instrumentation (e.g., add functions). */

			/* check if there is a function in a target program that conflicts
			 * with the probe functions */			
			if (M.getFunction(StringRef("_init_")) != NULL) {
				errs() << "Error: function _init_() already exists.\n" ;
				exit(1) ;
			}
			if (M.getFunction(StringRef("_probe_")) != NULL) {
				errs() << "Error: function _probe_() already exists.\n" ;
				exit(1) ;
			}

			errs() << "Running intwrite pass\n";

			llvm::LLVMContext &ctx = M.getContext() ;

			/* store the type instances for primitive types */
			intTy = Type::getInt32Ty(ctx) ;
			ptrTy = PointerType::get(ctx, 0);
			voidTy = Type::getVoidTy(ctx) ;
			boolTy = Type::getInt1Ty(ctx) ;

			/* add a new declaration of function _init_ which has no argument */
			FunctionType * fty = FunctionType::get(voidTy, false) ;
			p_init = M.getOrInsertFunction("_init_", fty) ;

			/* add a new declaration of function _probe_ which accept three
			 * arguments (i.e., int, char *, and int) */
			Type * args_types[3] ;
			args_types[0] = intTy ; //Type::getInt32Ty(*ctx) ;
			args_types[1] = ptrTy ; //Type::getInt8PtrTy(*ctx) ;	
			args_types[2] = intTy ; //Type::getInt32Ty(*ctx) ;	
			p_probe = M.getOrInsertFunction("_probe_", 
					FunctionType::get(voidTy, ArrayRef<Type *>(args_types), false)) ;

			/* add a function call to _init_ at the beginning of 
			 * the main function*/
			Function * mainFunc = M.getFunction(StringRef("main"));
			IRB = new IRBuilder<>(ctx);
			if (mainFunc != NULL) {
				IRB->SetInsertPoint(mainFunc->getEntryBlock().getFirstNonPHIOrDbgOrLifetime());
				IRB->CreateCall(p_init, {}) ;
			}

			return true ;
		} // doInitialization.

		bool runOnBasicBlock (BasicBlock &B) {
			/* This function is invoked for each basic block
				* in the function.*/

			StringRef funcname = "unknown";
			DISubprogram * disubp = B.getParent()->getSubprogram();
			if (disubp) {
				funcname = disubp->getName();
			}


			for (BasicBlock::iterator i = B.begin() ; i != B.end() ; i++) {
				/* for each instruction of the basic block in order */

				if (i->getOpcode() == Instruction::Store) {
					if (i->getOperand(0)->getType() == intTy) {
						StoreInst * st = dyn_cast<StoreInst>(i) ;

						/* add a function call to _probe_ right before
							* a store instruction on an integer variable. */

						const DebugLoc &debugloc = st->getDebugLoc();

						int loc = -1;
						if (debugloc) {
							loc = debugloc.getLine();
						}

						// Value * var = st->getPointerOperand() ; // the target variable 
						Value * val = st->getOperand(0) ; // the value to be assigned.

						IRB->SetInsertPoint(&(*i));

						Value * args[3];
						args[0] = ConstantInt::get(intTy, loc, false) ; // location of store instruction.
						args[1] = IRB->CreateGlobalString(funcname) ; // create a new string constant of the variable name, and get the pointer to it.
						args[2] = val; // the value to be assigned to the variable.
						IRB->CreateCall(p_probe, args, Twine("")) ;
						continue;
					}
				}	
			}
			return true ;
		} // runOnBasicBlock.
  };
}

/* The code in the remaining part is to register this Pass to
 * LLVM Pass Manager such that LLVM/Clang can use it. */
extern "C" ::llvm::PassPluginLibraryInfo llvmGetPassPluginInfo() {
  return {LLVM_PLUGIN_API_VERSION,  // Plugin API version
          "IntWritePassPlugin",   // Plugin name
          LLVM_VERSION_STRING,      // LLVM version
          [](PassBuilder &PB) {
            // Register module-level pass
            PB.registerPipelineStartEPCallback(
                [](ModulePassManager &MPM, OptimizationLevel _level) {
                  MPM.addPass(IntWrite());
                  return true;
                });
          }};
}